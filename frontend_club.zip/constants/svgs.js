import gicon from "../assets/icons/gicon.png";
import ficon from "../assets/icons/ficon.svg";
import ticon from "../assets/icons/ticon.svg";
import nbell from "../assets/icons/notificationbell.svg";
import upload from "../assets/icons/upload.svg";
import back from "../assets/icons/back.svg";
import credit from "../assets/icons/creditcard.svg";
import paypal from "../assets/icons/paypal.svg";
import applepay from "../assets/icons/applepay.svg";
import more from "../assets/icons/more.svg";
import card from "../assets/icons/card.svg";
import success from "../assets/icons/success.svg";
import help from "../assets/icons/help.svg";
import TrashSimple from "../assets/icons/TrashSimple.svg";
import Group from "../assets/icons/Group 40.svg";
import zara from "../assets/icons/zara.svg"
import gucci from "../assets/icons/gucci.svg"
import hm from "../assets/icons/h&m.svg"
import nike from "../assets/icons/nike.svg"
import home from "../assets/icons/home.svg"
import sort1 from "../assets/icons/sort1.svg"
import arrow from "../assets/icons/ArrowDropDownFilled.svg"
import pic1 from "../assets/Picture1.png"
import pic2 from "../assets/Picture2.png"
import pic3 from "../assets/Picture3.png"
import pic4 from "../assets/Picture4.png"
import slider1 from "../assets/slider1.png"
import profile from "../assets/icons/profile.svg"
// import Forgot from "../assets/icons/Forgot_password.svg"
// import slider2 from "../assets/slidet2.png"
import forgot from "../assets/icons/Forgot _password.svg"
export default {
  gicon,
  ficon,
  ticon,
  nbell,
  upload,
  back,
  TrashSimple,
  Group,
  credit,
  paypal,
  applepay,
  more,
  card,
  success,
  help,
  zara,
  gucci,
  hm,
  nike,
  home,
  sort1,
  arrow,
  pic1,
  pic2,
  pic3,
  pic4,
  slider1,
  // slider2,
  profile,
  forgot,
};
