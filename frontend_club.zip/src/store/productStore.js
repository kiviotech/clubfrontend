// import create from 'zustand';

// const useProductStore = create((set) => ({
//   products: [],
//   setProducts: (products) => set({ products }),
//   selectedBrand: '',
//   setSelectedBrand: (brand) => set({ selectedBrand: brand }),
// }));

// export default useProductStore; // Ensure this line is present
