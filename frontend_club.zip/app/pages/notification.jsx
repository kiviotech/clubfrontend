import { View, Text } from 'react-native'
import React from 'react'

const notification = () => {
  return (
    <View>
      <Text>notification</Text>
    </View>
  )
}

export default notification