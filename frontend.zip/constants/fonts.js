// /constants/fonts.js

export default {
    "Poppins-Black": "Poppins-Black",
    "Poppins-Bold": "Poppins-Bold",
    "Poppins-ExtraBold": "Poppins-ExtraBold",
    "Poppins-ExtraLight": "Poppins-ExtraLight",
    "Poppins-Light": "Poppins-Light",
    "Poppins-Medium": "Poppins-Medium",
    "Poppins-Regular": "Poppins-Regular",
    "Poppins-SemiBold": "Poppins-SemiBold",
    "Poppins-Thin": "Poppins-Thin",
};
