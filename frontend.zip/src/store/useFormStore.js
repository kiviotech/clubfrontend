// stores/useFormStore.js

import {create} from 'zustand';

const useFormStore = create((set) => ({
  designDetails: {
    title: '',
    description: '',
    fabric: '',
    color: '',
    deadline: '',
    budget: '',
  },
  measurements: {
    bust: '',
    waist: '',
    hip: '',
    height: '',
    weight: '',
    specialInstructions: '',
  },
  uploads: {
    images: [],
    // files: [],
  },
  // Method to update design details
  setDesignDetails: (details) => set((state) => {
    // console.log("Updating designDetails:", { ...state.designDetails, ...details });
    return {
      designDetails: { ...state.designDetails, ...details },
    };
  }),
  // Method to update measurements
  setMeasurements: (measurements) => set((state) => ({
    measurements: { ...state.measurements, ...measurements },
  })),
  // Method to update uploads
  setUploads: (uploads) => set((state) => ({
    uploads: { ...state.uploads, ...uploads },
  })),
  // Method to reset form data
  resetFormData: () => set({
    designDetails: {
      title: '',
      description: '',
      fabric: '',
      color: '',
      deadline: '',
      budget: '',
    },
    measurements: {
      bust: '',
      waist: '',
      hip: '',
      height: '',
      weight: '',
      specialInstructions: '',
    },
    uploads: {
      images: [],
    //   files: [],
    },
  }),
}));

export default useFormStore;
